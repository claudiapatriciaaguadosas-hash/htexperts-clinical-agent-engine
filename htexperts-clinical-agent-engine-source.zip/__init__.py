"""Channel and product adapters."""

